/***********************************************
Inverted Pendulum Control
***********************************************/
#include "weight_bias_data.h"
#include "control.h"
#include <math.h>

short Accel_Y,Accel_Z,Accel_X,Accel_Angle_x,Accel_Angle_y,Gyro_X,Gyro_Z,Gyro_Y;
//LQR parameter
float K11=81.2695, K12=-10.0616, K13=-5492.4061, K14=18921.7098, K15=100.3633, K16=8.0376, K17=447.3084, K18=2962.7738;
float K21=-10.0616, K22=81.2695, K23=-5492.4061, K24=18921.7098, K25=8.0376, K26=100.3633, K27=447.3084, K28=2962.7738;
//relevant variable
float Target_theta_L, Target_theta_R, Target_theta_L_dot, Target_theta_R_dot, Target_theta_1;
float u_L, u_R;																							
float t=0.01;												//time step 10ms
float theta_2, last_theta_2, theta_dot_2, last_theta_dot_2;	//tilt angle of the stick (rad),tilt angle of the stick at last time (rad), tilt angular velocity of the stick (rad/s), tilt angular velocity of the stick at last time (rad/s).
float theta_L_dot_instant, theta_R_dot_instant;				//rotation speed of left and right wheel (rad/s), 5ms.
float theta_L, theta_R, last_theta_L, last_theta_R;			//tilt angle of left wheel (rad), tilt angle of right wheel (rad), tilt angle of right wheel (rad), tilt angular velocity of right wheel (rad).
float theta_L_dot, theta_R_dot;								//mean rotation speed of left and right wheel (rad/s), 10ms.
float TargetVal_L, TargetVal_R;								//target velocity for left and right wheel (rad/s).
float theta_1,theta_dot_1;									//tilt angle of the body (rad), tilt angular velocity (rad/s).
float mid=3100;												//ADC value for balance position
int PWM_L, PWM_R;											//PWM for left and right wheel
int Moto_Ki=40, Moto_Kp=10;									//PI controller parameter
u8 count=0;													// count variable
u8 stop=0;

void controller(float theta_L, float theta_R, float theta_1, float theta_2,
				float theta_L_dot, float theta_R_dot, float theta_dot_1, float theta_dot_2)
{
	/**************************************************************************
	Implement controller here (give u_L and u_R)
	Function: Control function
	Input   : theta_L, theta_R, theta_1, theta_2, theta_L_dot, theta_R_dot, theta_dot_1, theta_dot_2
	Output  : u_L, u_R
	**************************************************************************/

	float x_L[6] = {theta_L, theta_1, theta_2, theta_L_dot, theta_dot_1, theta_dot_2};
	float x_R[6] = {theta_R, theta_1, theta_2, theta_R_dot, theta_dot_1, theta_dot_2};
	float u_max = 5000.0;

	// --------------- PREDICT THE OUTPUT ------------------- #

	float res_L[400] = { 0.0 };
	float res_R[400] = { 0.0 };
	for(int i=0; i<400; i++){
		// printf("%f\n", res_L[i]);
		for(int j=0; j<6; j++){
			res_L[i] += x_L[j] * layer1_weight[i][j];
			res_R[i] += x_R[j] * layer1_weight[i][j];
		}
		res_L[i] += layer1_bias[i];
		res_R[i] += layer1_bias[i];
		if (res_L[i] < 0) { res_L[i] = 0.0;} // ReLU
		if (res_R[i] < 0) { res_R[i] = 0.0;} // ReLU
	}
	float next_res_L[300] = { 0.0 };
	float next_res_R[300] = { 0.0 };
	for(int i=0; i<300; i++){
		for(int j=0; j<400; j++){
			next_res_L[i] += res_L[j] * layer2_weight[i][j];
			next_res_R[i] += res_R[j] * layer2_weight[i][j];
		}
		next_res_L[i] += layer2_bias[i];
		next_res_R[i] += layer2_bias[i];
		if (next_res_L[i] < 0) { next_res_L[i] = 0.0;} // ReLU
		if (next_res_R[i] < 0) { next_res_R[i] = 0.0;} // ReLU
	}	

	float final_res_L = 0.0;
	float final_res_R = 0.0;
	for (int i=0; i<300; i++){
		final_res_L += next_res_L[i] * layer3_weight[i];
		final_res_R += next_res_R[i] * layer3_weight[i];
	}
	final_res_L += layer3_bias;
	final_res_R += layer3_bias;

	u_L = tanh(final_res_L) * u_max; // last activation function and rescaling
	u_R = tanh(final_res_R) * u_max; // last activation function and rescaling
}

/**************************************************************************
Function: Control function
Input   : none
Output  : none
**************************************************************************/
int EXTI9_5_IRQHandler(void)
{
	static int Voltage_Temp,Voltage_Count,Voltage_All;		
	static u8 Flag_Target;																
	u8 key;
	
	if(INT==0)
	{
		EXTI->PR=1<<9;                           					  
		Encoder_Left=Read_Encoder(4);            					 
		Encoder_Right=-Read_Encoder(8);           					
		Angle_ADC = Get_Adc_Average(Angle_Ch,30);
		Flag_Target=!Flag_Target;
		Get_Angle(Way_Angle);                     				
		count += 1;																					
		
		//Switching the upper computer mode
		key = KEY_Scan(200,0);
		if( key==long_click ) Flag_Show  = !Flag_Show;
		
		if(delay_flag==1)
		{
			if(++delay_50==10)	 delay_50=0, delay_flag=0;  	//50ms delay
        }
		if(Flag_Target==1)                        					//10ms control once
		{
			Voltage_Temp=Get_battery_volt();		    					
			Voltage_Count++;                       						
			Voltage_All+=Voltage_Temp;              					
			if(Voltage_Count==100) Voltage=Voltage_All/100,Voltage_All=0,Voltage_Count=0;// average voltage
			return 0;	                                               
		}                                         					//10ms control once

		theta_L_dot_instant = Encoder_Left /60000.0f * PI*2.0f /0.005f;	//rotation speed of left wheel (rad/s)(5ms)
		Velocity_Left = theta_L_dot_instant*Diameter_67/2.0f;           //rotation speed of left wheel(mm/s)
		theta_L += theta_L_dot_instant*0.005f;													//angle left wheel turns (rad)

		theta_R_dot_instant = Encoder_Right/60000.0f * PI*2.0f /0.005f;	//rotation speed of right wheel (rad/s)(5ms)
		Velocity_Right = theta_R_dot_instant*Diameter_67/2.0f;          //rotation speed of right wheel (mm/s)
		theta_R += theta_R_dot_instant*0.005f;													//angle right wheel turns (rad)

		Displacement+=(Velocity_Left+Velocity_Right)*0.005/2;				//Displacement of the car (mm)

		theta_1 = Angle_Balance/180.0f*PI;													//tilt angle of the body (rad)
		theta_dot_1 += Gyro_Balance/16.4f*(PI/180.0f);  						//tilt angular velocity of the body (rad/s) (5ms).

		if (count == 2)
		{
			count = 0;																				

			theta_L_dot = (theta_L - last_theta_L)/t;					//mean rotation speed of left wheel (rad/s)(10ms)
			last_theta_L = theta_L;

			theta_R_dot = (theta_R - last_theta_R)/t;					//mean rotation speed of right wheel (rad/s)(10ms)
			last_theta_R = theta_R;

			theta_dot_1 = theta_dot_1*0.5;										//mean rotation speed of body (rad/s)(10ms)

			theta_2 = ( Angle_Balance + angle_count(Angle_ADC, mid) ) / 180.0f * PI;  //tilt angle of the stick(rad)
			theta_dot_2 = (theta_2 - last_theta_2) / t;																//tilt angular velocity of the stick(rad/s)(10ms)
			theta_dot_2 = 0.4*theta_dot_2 + 0.6*last_theta_dot_2;											//First-order low-pass filtering
			last_theta_dot_2 = theta_dot_2;
			last_theta_2 = theta_2;

			Normal();		//Normal mode 

			// Controller
			controller(theta_L, theta_R, theta_1, theta_2, theta_L_dot, theta_R_dot, theta_dot_1, theta_dot_2);

			if ( (theta_1<0.7854 && theta_1>-0.7854) )
			{
				TargetVal_L = theta_L_dot + u_L*t;											//target velocity for left wheel
				TargetVal_R = theta_R_dot + u_R*t;											//target velocity for right wheel
				PWM_L=Incremental_L(theta_L_dot_instant,TargetVal_L);		//PI control for left wheel
				PWM_R=Incremental_R(theta_R_dot_instant,TargetVal_R);		//PI control for right wheel
			}
			else
			{
				stop = 1;
				PWM_L = 0;
				PWM_R = 0;
			}
			theta_dot_1 = 0;
		}

		if(Mode==Normal_Mode)	Led_Flash(100);         //LED mode
		else Led_Flash(0);                              //

		PWM_L=PWM_Limit(PWM_L,6900,-6900);		  		//PWM limit
		PWM_R=PWM_Limit(PWM_R,6900,-6900);		  		//PWM limit
		Motor_Left=PWM_L;                              //PWM for left motor
		Motor_Right=PWM_R;                             //PWM for right motor

		Set_Pwm(PWM_L,PWM_R);	                       //Assign to PWM register
		
		//Dial emergency stop switch
		Flag_Stop=KEY2_STATE;
		if(Voltage<10) Flag_Stop = 1;
		if(Flag_Stop) PWMA_IN1=0,PWMA_IN2=0,PWMB_IN1=0,PWMB_IN2=0;
	 }
	 return 0;
}

/**************************************************************************
function: incremental PI controller
input: measured speed, target speed
output: PWM value
**************************************************************************/
static int Incremental_L(float CurrentVal,float TargetVal)
{
	float Bias;
	static float  Last_bias;
	static int PWM;

	Bias =  TargetVal - CurrentVal;
	PWM += Moto_Ki*Bias + Moto_Kp*(Bias-Last_bias);
	Last_bias=Bias;
	
	//Clearing historical values after stopping operation
	if(Flag_Stop || stop ) PWM=0,stop=0;
	
	return PWM;
}
/**************************************************************************
function: incremental PI controller
input: measured speed, target speed
output: PWM value
**************************************************************************/
static int Incremental_R(float CurrentVal,float TargetVal)
{
	float Bias;
	static float  Last_bias;
	static int PWM;

	Bias =  TargetVal - CurrentVal;
	PWM += Moto_Ki*Bias + Moto_Kp*(Bias-Last_bias);
	Last_bias=Bias;
	
	//Clearing historical values after stopping operation
	if(Flag_Stop || stop ) PWM=0,stop=0;
	
	return PWM;
}
/**************************************************************************
function: Calculation of the angle from the input ADC value
input: current ADC value, reference zero (median value)
output: current angle
**************************************************************************/
static float angle_count(float Angle_ADC, float mid)
{
	float Angle;
	Angle = (mid - Angle_ADC)*0.0879f;
	return Angle;
}
/**************************************************************************
Function: Assign to PWM register
Input   : motor_left, Left wheel PWM, motor_right, Right wheel PWM
Output  : none
**************************************************************************/
void Set_Pwm(int motor_left,int motor_right)
{
	//left wheel forward
  if(motor_left>0)
	{
		PWMA_IN1=7200;
		PWMA_IN2=7200-motor_left;
	}
	//left wheel backward
	else
	{
		PWMA_IN1=7200+motor_left;
		PWMA_IN2=7200;
	}
	//right wheel forward
  if(motor_right>0)
	{
		PWMB_IN1=7200-motor_right;
		PWMB_IN2=7200;
	}
	//right wheel backward
	else
	{
		PWMB_IN1=7200;
		PWMB_IN2=7200+motor_right;
	}
}
/**************************************************************************
Function: PWM limiting range
Input   : IN: Input  max: Maximum value  min: Minimum value
Output  : PWM after limiting range
**************************************************************************/
int PWM_Limit(int IN,int max,int min)
{
	int OUT = IN;
	if(OUT>max) OUT = max;
	if(OUT<min) OUT = min;
	return OUT;
}
/**************************************************************************
Function: If abnormal, turn off the motor
Input   : angle: Car inclination: voltage: Voltage
Output  : 1: abnormal 0: normal
**************************************************************************/	
u8 Turn_Off(float angle, int voltage)
{
	u8 temp;
	Flag_Stop = KEY2_STATE;                             
	if(KEY2_STATE==1) Pick_up_stop=0;                  
	if(angle<-40||angle>40||1==Flag_Stop||voltage<1110||Pick_up_stop==1)
	{	                                                 
		temp=1;                                          
		PWMA_IN1=0;                                           
		PWMA_IN2=0;
		PWMB_IN1=0;
		PWMB_IN2=0;
	}
	else
		temp=0;
	return temp;			
}
///**************************************************************************
//Function: Get angle
//Input   : way: The algorithm of getting angle 1: DMP  2: kalman  3: Complementary filtering
//Output  : none
//**************************************************************************/	
void Get_Angle(u8 way)
{ 
  	float gyro_x,gyro_y,accel_x,accel_y,accel_z;
	//Temperature=Read_Temperature();      
	if(way==1)                           
	{	
		Read_DMP();                      	 
		Angle_Balance=Pitch;             	 
		Gyro_Balance=gyro[0];              
		Gyro_Turn=gyro[2];                 
		Acceleration_Z=accel[2];           
	}			
	else
	{
		Gyro_X=(I2C_ReadOneByte(devAddr,MPU6050_RA_GYRO_XOUT_H)<<8)+I2C_ReadOneByte(devAddr,MPU6050_RA_GYRO_XOUT_L);    //X Gyro
		Gyro_Y=(I2C_ReadOneByte(devAddr,MPU6050_RA_GYRO_YOUT_H)<<8)+I2C_ReadOneByte(devAddr,MPU6050_RA_GYRO_YOUT_L);    //Y Gyro
		Gyro_Z=(I2C_ReadOneByte(devAddr,MPU6050_RA_GYRO_ZOUT_H)<<8)+I2C_ReadOneByte(devAddr,MPU6050_RA_GYRO_ZOUT_L);    //Z Gyro
		Accel_X=(I2C_ReadOneByte(devAddr,MPU6050_RA_ACCEL_XOUT_H)<<8)+I2C_ReadOneByte(devAddr,MPU6050_RA_ACCEL_XOUT_L); //X Acc
		Accel_Y=(I2C_ReadOneByte(devAddr,MPU6050_RA_ACCEL_YOUT_H)<<8)+I2C_ReadOneByte(devAddr,MPU6050_RA_ACCEL_YOUT_L); //Y Acc
		Accel_Z=(I2C_ReadOneByte(devAddr,MPU6050_RA_ACCEL_ZOUT_H)<<8)+I2C_ReadOneByte(devAddr,MPU6050_RA_ACCEL_ZOUT_L); //Z Acc
		Gyro_Balance=-Gyro_X;                            
		accel_x=Accel_X/1671.84;
		accel_y=Accel_Y/1671.84;
		accel_z=Accel_Z/1671.84;
		gyro_x=Gyro_X/939.8;                              
		gyro_y=Gyro_Y/939.8;                              
		if(Way_Angle==2)		  	
		{
			 Pitch= KF_X(accel_y,accel_z,-gyro_x)/PI*180;// kalman filter
			 Roll = KF_Y(accel_x,accel_z,gyro_y)/PI*180;
		}
		else if(Way_Angle==3) 
		{  
			 Pitch = -Complementary_Filter_x(Accel_Angle_x,gyro_x);//complementary filtering
			 Roll = -Complementary_Filter_y(Accel_Angle_y,gyro_y);
		}
		Angle_Balance=Pitch;                             
		Gyro_Turn=Gyro_Z;                                 
		Acceleration_Z=Accel_Z;                           
	}
}
/**************************************************************************
Function: Absolute value function
Input   : a: Number to be converted
Output  : unsigned int
**************************************************************************/	
int myabs(int a)
{ 		   
	int temp;
	if(a<0)  temp=-a;  
	else temp=a;
	return temp;
}
/**************************************************************************
Function: Normal
Input   : none
Output  : none
**************************************************************************/
void Normal(void)
{
	if(Mode == Normal_Mode)									  //normal mode can use handle control
	{
		//forward, backward
		if(Flag_front==1)
		{
			Target_theta_L += 0.10;
			Target_theta_R += 0.10;
			Target_theta_L_dot = 0.01;
			Target_theta_R_dot = 0.01;
			Target_theta_1 = 0.0349*2;
		}
		else if(Flag_back==1)
		{
			Target_theta_L -= 0.10;
			Target_theta_R -= 0.10;
			Target_theta_L_dot = -0.01;
			Target_theta_R_dot = -0.01;
			Target_theta_1 = 0.0349*-2;
		}
		//turn left, turn right
		else if(Flag_Left==1)
		{
			Target_theta_L -= 0.01;
			Target_theta_R += 0.01;
			Target_theta_L_dot = -0.001;
			Target_theta_R_dot =  0.001;
			Target_theta_1 = 0;
		}
		else if(Flag_Right==1)
		{
			Target_theta_L += 0.01;
			Target_theta_R -= 0.01;
			Target_theta_L_dot =  0.001;
			Target_theta_R_dot = -0.001;
			Target_theta_1 = 0;
		}
		// cancel control 
		{
			Target_theta_L_dot = 0;
			Target_theta_R_dot = 0;
			Target_theta_1 = 0;
		}
	}
}