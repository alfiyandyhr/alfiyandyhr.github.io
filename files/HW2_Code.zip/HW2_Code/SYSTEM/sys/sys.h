/***********************************************

All rights reserved
***********************************************/
#ifndef __SYS_H
#define __SYS_H	  
#include <stm32f10x.h>   
#define SYSTEM_SUPPORT_UCOS		0		
																	    
	 

#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
#define GPIOA_ODR_Addr    (GPIOA_BASE+12) //0x4001080C 
#define GPIOB_ODR_Addr    (GPIOB_BASE+12) //0x40010C0C 
#define GPIOC_ODR_Addr    (GPIOC_BASE+12) //0x4001100C 
#define GPIOD_ODR_Addr    (GPIOD_BASE+12) //0x4001140C 
#define GPIOE_ODR_Addr    (GPIOE_BASE+12) //0x4001180C 
#define GPIOF_ODR_Addr    (GPIOF_BASE+12) //0x40011A0C    
#define GPIOG_ODR_Addr    (GPIOG_BASE+12) //0x40011E0C    

#define GPIOA_IDR_Addr    (GPIOA_BASE+8) //0x40010808 
#define GPIOB_IDR_Addr    (GPIOB_BASE+8) //0x40010C08 
#define GPIOC_IDR_Addr    (GPIOC_BASE+8) //0x40011008 
#define GPIOD_IDR_Addr    (GPIOD_BASE+8) //0x40011408 
#define GPIOE_IDR_Addr    (GPIOE_BASE+8) //0x40011808 
#define GPIOF_IDR_Addr    (GPIOF_BASE+8) //0x40011A08 
#define GPIOG_IDR_Addr    (GPIOG_BASE+8) //0x40011E08 
 

#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //    
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //     

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //    
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //     

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  //    
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  //     

#define PDout(n)   BIT_ADDR(GPIOD_ODR_Addr,n)  //    
#define PDin(n)    BIT_ADDR(GPIOD_IDR_Addr,n)  //     

#define PEout(n)   BIT_ADDR(GPIOE_ODR_Addr,n)  //    
#define PEin(n)    BIT_ADDR(GPIOE_IDR_Addr,n)  //    

#define PFout(n)   BIT_ADDR(GPIOF_ODR_Addr,n)  //    
#define PFin(n)    BIT_ADDR(GPIOF_IDR_Addr,n)  //    

#define PGout(n)   BIT_ADDR(GPIOG_ODR_Addr,n)  //    
#define PGin(n)    BIT_ADDR(GPIOG_IDR_Addr,n)  //    
/////////////////////////////////////////////////////////////////
//Ex_NVIC_Configר ö   
#define GPIO_A 0
#define GPIO_B 1
#define GPIO_C 2
#define GPIO_D 3
#define GPIO_E 4
#define GPIO_F 5
#define GPIO_G 6 

#define FTIR   1  // ½  
#define RTIR   2  //     
#include "delay.h"
#include "led.h"
#include "key.h"
#include "oled.h"
#include "usart.h"
#include "usart3.h"
#include "adc.h"
#include "timer.h"
#include "motor.h"
#include "encoder.h"
#include "ioi2c.h"
#include "mpu6050.h"
#include "show.h"					
#include "exti.h"
#include "DataScope_DP.h"
#include "control.h"
#include "filter.h"	
#include "Lidar.h"
#include "beep.h"
#include "ELE_CCD.h"
#include "pstwo.h"
#include "KF.h"
////JTAGģʽ   ö   
#define JTAG_SWD_DISABLE   0X02
#define SWD_ENABLE         0X01
#define JTAG_SWD_ENABLE    0X00	

#define	digitalHi(p,i)		 {p->BSRR=i;}	 	//   	
#define digitalLo(p,i)		 {p->BRR=i;}	 	//    
#define digitalToggle(p,i) {p->ODR ^=i;} 		//     
#define Lidar_Detect_ON						1				//   
#define Lidar_Detect_OFF					0
extern u8 Ros_Rate ;
extern volatile u8 Ros_count;
extern u8 Pick_up_stop;                       // 
extern int Middle_angle;                      //  
extern u8 Lidar_Detect;
extern u8 Mode ;                                                    //
extern u8 PS2_ON_Flag;		//  
extern float RC_Velocity,RC_Turn_Velocity;			//
extern u8 Way_Angle;                                       				 // 
extern int Motor_Left,Motor_Right;                                 //   PWM      motor    
extern u16 Flag_front,Flag_back,Flag_Left,Flag_Right,Flag_velocity,Target_Velocity; //    
extern u8 Flag_Stop,Flag_Show;                               			   
extern int Voltage;               																   
extern float Angle_Balance,Gyro_Balance,Gyro_Turn;     						   
extern int Temperature;
extern u32 Distance;                                          		
extern u16 determine;                                       
extern int Encoder_Left,Encoder_Right;             				           
extern float Move_X,Move_Z;
extern u8 Flag_follow,Flag_avoid,Flag_straight,delay_50,delay_flag,PID_Send;
extern float Acceleration_Z;                       //Z    
extern float Balance_Kp,Balance_Kd,Velocity_Kp,Velocity_Ki,Turn_Kp,Turn_Kd;
extern float Distance_KP ,Distance_KD  ,Distance_KI ;	//       PID    
extern u8 CCD_Zhongzhi,CCD_Yuzhi;                 //    CCD   
extern u16 Angle_ADC;
/////////////////////////////////////////////////////////////////  
void Stm32_Clock_Init(u8 PLL);  //   
void Sys_Soft_Reset(void);      //ϵͳ    λ
void Sys_Standby(void);         //    
void MY_NVIC_SetVectorTable(u32 NVIC_VectTab, u32 Offset);//   
void MY_NVIC_PriorityGroupConfig(u8 NVIC_Group);//    NVIC    
void MY_NVIC_Init(u8 NVIC_PreemptionPriority,u8 NVIC_SubPriority,u8 NVIC_Channel,u8 NVIC_Group);//     ж 
void Ex_NVIC_Config(u8 GPIOx,u8 BITx,u8 TRIM);// ⲿ ж    ú   (ֻ  GPIOA~G)
void JTAG_Set(u8 mode);
//////////////////////////////////////////////////////////////////////////////
//    
void WFI_SET(void);		  //ִ  WFIָ  
void INTX_DISABLE(void);// 
void INTX_ENABLE(void);	//        
void MSR_MSP(u32 addr);	//   ö 
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "dmpKey.h"
#include "dmpmap.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#endif











