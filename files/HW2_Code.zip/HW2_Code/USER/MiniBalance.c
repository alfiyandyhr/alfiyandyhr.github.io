/***********************************************


All rights reserved
***********************************************/
#include "stm32f10x.h"
#include "sys.h" 
u8 Pick_up_stop=0;                          //   
int Middle_angle=0;                         //  
u8 Way_Angle=2;                         
u16 Flag_front,Flag_back,Flag_Left,Flag_Right,Flag_velocity=2,Target_Velocity=300; //  
float RC_Velocity,RC_Turn_Velocity;			    //
u8 Flag_Stop=1,Flag_Show=0;                 //  
u8 PS2_ON_Flag = 0;		                      
u8 Mode = 0;								            
float Move_X,Move_Z;                        
u16 determine;                            
int Encoder_Left,Encoder_Right;             //       
int Motor_Left,Motor_Right;                 //   PWM     Motor   	
int Temperature;                            // 
int Voltage;                                //  
float Angle_Balance,Gyro_Balance,Gyro_Turn; //   
u32 Distance;                               // 
u8 delay_50,delay_flag,PID_Send; 						// 
u8 Flag_follow=0,Flag_avoid=0,Flag_straight=0;							// 
u8 Lidar_Detect = Lidar_Detect_ON;			//  
float Acceleration_Z;                       //  
u8 CCD_Zhongzhi,CCD_Yuzhi;                 //    CCD   
float Balance_Kp=27000,Balance_Kd=110,Velocity_Kp=400,Velocity_Ki=2,Turn_Kp=4200,Turn_Kd=100;//PID        
u16 Angle_ADC = 0;

int main(void)
{ 
  MY_NVIC_PriorityGroupConfig(2);	//  
	delay_init();	    	            // 	
	JTAG_Set(JTAG_SWD_DISABLE);     // 
	JTAG_Set(SWD_ENABLE);           //    
	LED_Init();                     //     LED   
	KEY_Init();                     //      
	BEEP_GPIO_Config();             //        
	MiniBalance_PWM_Init(7199,0);   //    PWM 10KHZ           
	uart_init(115200);	            //    1   
	uart3_init(9600);             	//    3           
	PS2_Init();                     //
	Encoder_Init_TIM8();            //       8
	Encoder_Init_TIM4();            //       4
	Adc_Init();                     //adc  
	IIC_Init();                     //IIC  
	OLED_Init();                    //OLED  	 	
	MPU6050_initialize();           //MPU6050  
	DMP_Init();                     // DMP 
	LIDAR_USART_Init();             //  230400
  MiniBalance_EXTI_Init();	      //MPU6050 5ms   cpu    
	while(1)
	{	
	  if(Flag_Show==0)          		//ʹ  MiniBalance APP  OLED  ʾ  
		{
			 APP_Show();								//    APP
			 oled_show();          			//    
			 PS2_Read();								// 
		}
		else                      		//ʹ  MiniBalance   ֺ OLED  ʾ  
		{
			 DataScope();          			//    MiniBalance  λ  
		}	
		delay_flag=1;	
		delay_50=0;
		while(delay_flag);		       //ʾ     50ms	     delay   
	}
}

