/***********************************************
All rights reserved
***********************************************/
#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"
#define KEY PAin(0)
#define KEY_ON	1
#define KEY_OFF	0
//ûֵ״̬
#define No_Action 					0
#define Click 						1
#define Long_Press 					2
#define Double_Click				3
#define KEY2_STATE  		 PCin(13)

//״̬ö
enum {
	key_stateless,
	single_click,
	double_click,
	long_click
};

u8 KEY_Scan(u16 Frequency,u16 filter_times);

void KEY_Init(void);          //ʼ
uint8_t User_Key_Scan(void);
void Mode_Choose(void);
#endif  
