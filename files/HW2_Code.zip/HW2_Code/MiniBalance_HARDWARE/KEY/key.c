/***********************************************

All rights reserved
***********************************************/
#include "key.h"
/**************************************************************************
Function: Key initialization
Input   : none
Output  : none
**************************************************************************/
void KEY_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |RCC_APB2Periph_GPIOC, ENABLE); //ʹPA˿ʱ
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;	            //˿
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;         //
  GPIO_Init(GPIOA, &GPIO_InitStructure);					      //趨ʼGPIOA 
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;	            //˿
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;         //
  GPIO_Init(GPIOC, &GPIO_InitStructure);					      //趨ʼGPIOA 
} 

/*************************************************************************
Function:Mode Choose
Iput    :None
Output  :Noce

*************************************************************************/
void Mode_Choose(void)
{
	switch(User_Key_Scan())
		{

			case Click:
				Mode++;
				 if(Mode == 3)							//3ģʽѭл
				{
					Mode = Normal_Mode;
				}
				break;
			case Long_Press:
				Flag_Show = !Flag_Show;								// /˳ λģʽ
				break;
			default:break;
		}
}

/*************************************************************************
Function:User_Key_Scan
Input:None
Output:Key_status
ܣû
ڲ
ֵ  ״̬
**************************************************************************/
//5msже
uint8_t User_Key_Scan(void)
{
	static u16 count_time = 0;					//㰴µʱ䣬ÿ5ms1
	static u8 key_step = 0;						//¼ʱĲ
	switch(key_step)
	{
		case 0:
			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == KEY_ON )
				key_step++;						//⵽а£һ
			break;
		case 1:
			if((++count_time) == 5)				//ʱ
			{
				if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == KEY_ON )//ȷʵ
					key_step++,count_time = 0;	//һ
				else
					count_time = 0,key_step = 0;//λ
			}
			break;
		case 2:
			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == KEY_ON )
				count_time++;					//㰴µʱ
			else 								//ʱɿ
				key_step++;						//һ
			break;
		case 3:									//ʱµʱ䣬жǳǶ̰
			if(count_time > 400)				//5msжеãʰʱ400*5 = 2000msֵ
			{							
				key_step = 0;					//־λλ
				count_time = 0;
				return Long_Press;				//  ״̬ 
 			}
			else if(count_time > 5)				//ʱǵһ
			{
				key_step++;						//ʱһжǷ˫
				count_time = 0;					//µʱ
			}
			else
			{
				key_step = 0;
				count_time = 0;	
			}
			break;
		case 4:									//жǷ˫򵥻
			if(++count_time == 38)				//5*38 = 190msжϰǷ
			{
				if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == KEY_ON )	//ȷʵ
				{																	//˫̫ܰ죬ʶɵ
					key_step++;														//һҪֲͷ״̬
					count_time = 0;
				}
				else																//190msް£ʱǵ״̬
				{
					key_step = 0;				//־λλ
					count_time = 0;					
					return Click;				//ص״̬
				}
			}
			break;
		case 5:
			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == KEY_ON )//ڰ
			{
				count_time++;
			}
			else								//Ѿ
			{
//				if(count_time>400)				//ڶεĵҲжʱģĬϲжʱ䣬ȫ˫
//				{
//				}
				count_time = 0;
				key_step = 0;
				return Double_Click;
			}
			break;
		default:break;
	}
	return No_Action;							//޶
}


/**************************************************************************
ܣɨ躯
ڲִиúƵʡӳ˲ʱ
  ֵlong_clickdouble_clicksingle_clickkey_stateless˫״̬
    ߣWHEELTEC
**************************************************************************/
u8 KEY_Scan(u16 Frequency,u16 filter_times)
{
    static u16 time_core;//ʱ
    static u16 long_press_time;//ʶ
    static u8 press_flag=0;//±
    static u8 check_once=0;//ǷѾʶ1α
    static u16 delay_mini_1;
    static u16 delay_mini_2;
	
    float Count_time = (((float)(1.0f/(float)Frequency))*1000.0f);//1Ҫٸ

    if(check_once)//ʶб
    {
        press_flag=0;//1ʶ𣬱
        time_core=0;//1ʶʱ
        long_press_time=0;//1ʶʱ
        delay_mini_1=0;
        delay_mini_2=0;
    }
    if(check_once&&KEY==KEY_OFF) check_once=0; //ɨ󰴼һɨ

    if(KEY==KEY_ON&&check_once==0)//ɨ
    {
        press_flag=1;//Ǳ1
		
        if(++delay_mini_1>filter_times)
        {
            delay_mini_1=0;
            long_press_time++;		
        }
    }

    if(long_press_time>(u16)(500.0f/Count_time))// 1
    {	
        check_once=1;//ѱʶ
        return long_click; //
    }

    //1ֵ󣬿ںʱ
    if(press_flag&&KEY==KEY_OFF)
    {
        if(++delay_mini_2>filter_times)
        {
            delay_mini_2=0;
            time_core++; 
        }
    }		
	
    if(press_flag&&(time_core>(u16)(50.0f/Count_time)&&time_core<(u16)(300.0f/Count_time)))//50~700msڱٴΰ
    {
        if(KEY==KEY_ON) //ٴΰ
        {
            check_once=1;//ѱʶ
            return double_click; //Ϊ˫
        }
    }
    else if(press_flag&&time_core>(u16)(300.0f/Count_time))
    {
        check_once=1;//ѱʶ
        return single_click; //800msû£ǵ
    }

    return key_stateless;
}
