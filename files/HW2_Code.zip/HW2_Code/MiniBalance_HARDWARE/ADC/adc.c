/***********************************************

All rights reserved
***********************************************/
#include "adc.h"

/**************************************************************************
Function: Initialize the ADC
Input   : none
Output  : none
**************************************************************************/	 		
void Adc_Init(void)
{    
 	ADC_InitTypeDef ADC_InitStructure; 
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC |RCC_APB2Periph_ADC2	, ENABLE );	  //ADC2
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);   //ADCƵ6 72M/6=12,ADCʱ䲻ܳ14M
	
	//             
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;		//
	GPIO_Init(GPIOC, &GPIO_InitStructure);	
	
	
	ADC_DeInit(ADC2);  //λADC2, ADC2 ȫĴΪȱʡֵ
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;	//ADCģʽ:ADC1ADC2ڶģʽ
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;	//
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;	//
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;	//
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;	//
	ADC_InitStructure.ADC_NbrOfChannel = 1;	//
	ADC_Init(ADC2, &ADC_InitStructure);	//ADC_InitStruct
	ADC_Cmd(ADC2, ENABLE);	//ʹָADC1
	ADC_ResetCalibration(ADC2);	//	 
	while(ADC_GetResetCalibrationStatus(ADC2));	//
	ADC_StartCalibration(ADC2);	 
	while(ADC_GetCalibrationStatus(ADC2));	 //
}		



/**************************************************************************
Function: AD sampling
Input   : chChannel of ADC1
Output  : AD conversion result
**************************************************************************/	 		
u16 Get_Adc(u8 ch)   
{
	  	
	ADC_RegularChannelConfig(ADC2, ch, 1, ADC_SampleTime_239Cycles5 );	//ADC2,ADCͨ,Ϊ239.5	  			     
	ADC_SoftwareStartConvCmd(ADC2, ENABLE);		// 
	while(!ADC_GetFlagStatus(ADC2, ADC_FLAG_EOC ));//
	return ADC_GetConversionValue(ADC2);	
}

u16 Get_Adc_Average(u8 ch,u8 times)
{
	u32 temp_val=0;
	u8 t;
	for(t=0;t<times;t++)
	{
		temp_val+=Get_Adc(ch);
		delay_us(1);
	}
	return temp_val/times;
} 
	
/**************************************************************************
Function: Read battery voltage
Input   : none
Output  : Battery voltageMV
**************************************************************************/
int Get_battery_volt(void)   
{  
	int Volt;
	Volt=Get_Adc(Battery_Ch)*3.3*11*100/4096;	
	return Volt;
}


/**************************************************************************
Function: Get_Voltage
Input   : none
Output  : none
**************************************************************************/	 
//ȡADCֵ
u16 Get_Adc1(u8 ch)   
{
	//ָADCĹͨһУʱ
	ADC_RegularChannelConfig(ADC1, ch, 1, ADC_SampleTime_239Cycles5 );	
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);		
	__nop();
	while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC ));
	return ADC_GetConversionValue(ADC1);	//
}

