/***********************************************

All rights reserved
***********************************************/
  
#include "beep.h"   

/**************************************************************************
Function: Buzzer initialization
Input   : none
Output  : none
**************************************************************************/	 	
void BEEP_GPIO_Config(void)
{		

	/*һGPIO_InitTypeDef͵Ľṹ*/
	GPIO_InitTypeDef GPIO_InitStructure;

	/*رJTAGӿ*/
	JTAG_Set(JTAG_SWD_DISABLE);    

	/*SWDӿ SWDӿڵ*/
	JTAG_Set(SWD_ENABLE);           

	/*ƷGPIOĶ˿ʱ*/
	RCC_APB2PeriphClockCmd(BEEP_GPIO_CLK, ENABLE); 

	/*ѡҪƷGPIO*/															   
	GPIO_InitStructure.GPIO_Pin = BEEP_GPIO_PIN;	

	/*GPIOģʽΪͨ*/
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   

	/*GPIOΪ50MHz */   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; 

	/*ƷGPIO*/
	GPIO_Init(BEEP_GPIO_PORT, &GPIO_InitStructure);			 

	GPIO_ResetBits(BEEP_GPIO_PORT, BEEP_GPIO_PIN);	 
}



/**************************************************************************
Function: Buzzer_Alarm
Input   : Indicates the count of frequencies
Output  : none
**************************************************************************/	 	

void Buzzer_Alarm(u16 count)
{
	static int count_time;
	if(0 == count)
	{
		BEEP_OFF;
	}
	else if(++count_time >= count)
	{
		BEEP_TOGGLE;
		count_time = 0;	
	}
}




/*********************************************END OF FILE**********************/
