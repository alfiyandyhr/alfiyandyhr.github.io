/***********************************************


All rights reserved
***********************************************/
#include "encoder.h"
#include "stm32f10x_gpio.h"



/************************************************************
Function: Initialize TIM2 to encoder interface mode
Input   : none
Output  : none
**************************************************************************/
void Encoder_Init_TIM8(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;  
	//NVIC_InitTypeDef NVIC_InitStruct;
  TIM_ICInitTypeDef TIM_ICInitStructure;  
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);//ʹܶʱ8ʱ
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);//ʹPB˿ʱ
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;	//˿
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //
  GPIO_Init(GPIOC, &GPIO_InitStructure);					      //
  
  TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
  TIM_TimeBaseStructure.TIM_Prescaler = 0x0; // ԤƵ 
  TIM_TimeBaseStructure.TIM_Period = ENCODER_TIM_PERIOD; 
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
  TIM_TimeBaseInit(TIM8, &TIM_TimeBaseStructure);
  TIM_EncoderInterfaceConfig(TIM8, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
  TIM_ICStructInit(&TIM_ICInitStructure);
  TIM_ICInitStructure.TIM_ICFilter = 10;	//
  TIM_ICInit(TIM8, &TIM_ICInitStructure);// 
  TIM_ClearFlag(TIM8, TIM_FLAG_Update);//
  TIM_ITConfig(TIM8, TIM_IT_Update, ENABLE);
  //Reset counter
  TIM_SetCounter(TIM8,0);
  TIM_Cmd(TIM8, ENABLE); 
	

//	NVIC_InitStruct.NVIC_IRQChannel =TIM8_UP_IRQn;  		//
//	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;  			//
//	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;	//
//	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 3;       	//
//	NVIC_Init(&NVIC_InitStruct);
	
}
/**************************************************************************
Function: Initialize TIM4 to encoder interface mode
Input   : none
Output  : none
**************************************************************************/
void Encoder_Init_TIM4(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure; 
	//NVIC_InitTypeDef NVIC_InitStruct;	
  TIM_ICInitTypeDef TIM_ICInitStructure;  
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);//ʹܶʱ4ʱ
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);//ʹPB˿ʱ
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;	//˿
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //
  GPIO_Init(GPIOB, &GPIO_InitStructure);					      //
  
  TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
  TIM_TimeBaseStructure.TIM_Prescaler = 0x0; // ԤƵ 
  TIM_TimeBaseStructure.TIM_Period = ENCODER_TIM_PERIOD; //
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;//
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//// 
  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
  TIM_EncoderInterfaceConfig(TIM4, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);//
  TIM_ICStructInit(&TIM_ICInitStructure);
  TIM_ICInitStructure.TIM_ICFilter = 10;
  TIM_ICInit(TIM4, &TIM_ICInitStructure);
  TIM_ClearFlag(TIM4, TIM_FLAG_Update);//TIMĸ±־λ
  TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
 
  TIM_SetCounter(TIM4,0);
  TIM_Cmd(TIM4, ENABLE); 
	


//	NVIC_InitStruct.NVIC_IRQChannel = TIM4_IRQn;  		//ʱ4ж
//	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;  			//ʹIRQͨ
//	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;	//ռȼ1 
//	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 3;       	//Ӧȼ3
//	NVIC_Init(&NVIC_InitStruct);

}
/**************************************************************************
Function: Read encoder count per unit time
Input   : TIMXTimer
Output  : none
**************************************************************************/
int Read_Encoder(u8 TIMX)
{
   int Encoder_TIM;    
   switch(TIMX)
	 {
		 case 3:  Encoder_TIM= (short)TIM3 -> CNT;  TIM3 -> CNT=0;break;	
		 case 4:  Encoder_TIM= (short)TIM4 -> CNT;  TIM4 -> CNT=0;break;	
		 case 8:  Encoder_TIM= (short)TIM8 -> CNT;  TIM8 -> CNT=0;break;
		 default: Encoder_TIM=0;
	 }
		return Encoder_TIM;
}
/**************************************************************************
Function: TIM4 interrupt service function
Input   : none
Output  : none
**************************************************************************/
void TIM4_IRQHandler(void)
{ 		    		  			    
	if(TIM_GetFlagStatus(TIM4,TIM_FLAG_Update)==SET)//ж
	{
	 
	} 
	TIM_ClearITPendingBit(TIM4,TIM_IT_Update); 	//жϱ־λ 	    
}
/**************************************************************************
Function: TIM2 interrupt service function
Input   : none
Output  : none
**************************************************************************/
void TIM8_UP_IRQHandler(void)
{ 		    		  			    
	if(TIM_GetFlagStatus(TIM8,TIM_FLAG_Update)==SET)//
	{
	 
	} 
	TIM_ClearITPendingBit(TIM8,TIM_IT_Update); 	//   
}



