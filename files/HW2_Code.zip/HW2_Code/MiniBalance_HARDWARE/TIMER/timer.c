///***********************************************


//All rights reserved
//***********************************************/
//#include "timer.h"
///**************************************************************************
//Function: Timer 3 channel 3 input capture initialization
//Input   : arrAuto reload value psc Clock prescaled frequency
//Output  : none
//ܣʱ3ͨ3벶ʼ
//ڲ: arrԶװֵ pscʱԤƵ 
//  ֵ
//**************************************************************************/	 		
//TIM_ICInitTypeDef  TIM3_ICInitStructure;
//void TIM3_Cap_Init(u16 arr,u16 psc)	
//{	 
//	GPIO_InitTypeDef GPIO_InitStructure;
//	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
// 	NVIC_InitTypeDef NVIC_InitStructure;

//	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);	//ʹTIM3ʱ
// 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  //ʹGPIOBʱ
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  //ʹGPIOBʱ
//	
//	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1; 
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; //PA1   
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;     //50M
//	GPIO_Init(GPIOA, &GPIO_InitStructure);
//	
//	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;     
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     //PC15 
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;     //50M
//	GPIO_Init(GPIOC, &GPIO_InitStructure);
//	
//	//ʼʱ3 TIM3	 
//	TIM_TimeBaseStructure.TIM_Period = arr; //趨Զװֵ 
//	TIM_TimeBaseStructure.TIM_Prescaler =psc; 	//ԤƵ   
//	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; //ʱӷָ:TDTS = Tck_tim
//	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIMϼģʽ
//	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); //TIM_TimeBaseInitStructָĲʼTIMxʱλ
//  
//	//ʼTIM3벶
//	TIM3_ICInitStructure.TIM_Channel = TIM_Channel_3; //CC1S=03 	ѡ IC3ӳ䵽TI1
//  TIM3_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;	//ز
//  TIM3_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
//  TIM3_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;	 //Ƶ,Ƶ 
//  TIM3_ICInitStructure.TIM_ICFilter = 0x00;//˲ ˲
//  TIM_ICInit(TIM3, &TIM3_ICInitStructure);
//	
//	//жϷʼ
//	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;  //TIM3ж
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //ռȼ1
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;  //ȼ1
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQͨʹ
//	NVIC_Init(&NVIC_InitStructure);  //NVIC_InitStructָĲʼNVICĴ 	
//	TIM_ITConfig(TIM3,TIM_IT_Update|TIM_IT_CC3,ENABLE);//ж ,CC3IEж	
//  TIM_Cmd(TIM3,ENABLE ); 	//ʹܶʱ3
//}
///**************************************************************************
//Function: Ultrasonic receiving echo function
//Input   : none
//Output  : none
//ܣջز
//ڲ:  
//  ֵ
//**************************************************************************/	 	
//u16 TIM3CH3_CAPTURE_STA,TIM3CH3_CAPTURE_VAL;
//void Read_Distane(void)        
//{   
//	 PBout(1)=1;         
//	 delay_us(15);  
//	 PBout(1)=0;	
//	 if(TIM3CH3_CAPTURE_STA&0X80)//ɹһθߵƽ
//	 {
//		 Distance=TIM3CH3_CAPTURE_STA&0X3F; 
//		 Distance*=65536;					        //ʱܺ
//		 Distance+=TIM3CH3_CAPTURE_VAL;		//õܵĸߵƽʱ
//		 Distance=Distance*170/1000;      //ʱ*/2أ һ0.001ms
//		 TIM3CH3_CAPTURE_STA=0;			//һβ
//	 }				
//}
///**************************************************************************
//Function: Pulse width reading interruption of ultrasonic echo
//Input   : none
//Output  : none
//ܣزȡж
//ڲ:  
//  ֵ
//**************************************************************************/	 
//void TIM3_IRQHandler(void)
//{ 		    		  			    
//	u16 tsr;
//	tsr=TIM3->SR;
//	if((TIM3CH3_CAPTURE_STA&0X80)==0)//δɹ	
//	{
//		if(tsr&0X01)//ʱ
//		{	    
//			 if(TIM3CH3_CAPTURE_STA&0X40)//Ѿ񵽸ߵƽ
//			 {
//				 if((TIM3CH3_CAPTURE_STA&0X3F)==0X3F)//ߵƽ̫
//				 {
//					  TIM3CH3_CAPTURE_STA|=0X80;      //ǳɹһ
//						TIM3CH3_CAPTURE_VAL=0XFFFF;
//				 }else TIM3CH3_CAPTURE_STA++;
//			 }	 
//		}
//		if(tsr&0x08)//3¼
//		{	
//			if(TIM3CH3_CAPTURE_STA&0X40)		  //һ½ 		
//			{	  			
//				TIM3CH3_CAPTURE_STA|=0X80;		  //ǳɹһθߵƽ
//				TIM3CH3_CAPTURE_VAL=TIM3->CCR3;	//ȡǰĲֵ.
//				TIM3->CCER&=~(1<<9);			      //CC1P=0 Ϊز
//			}
//			else  								     //δʼ,һβ
//			{
//				 TIM3CH3_CAPTURE_STA=0;	 //
//				 TIM3CH3_CAPTURE_VAL=0;
//				 TIM3CH3_CAPTURE_STA|=0X40;		//ǲ
//				 TIM3->CNT=0;									//
//				 TIM3->CCER|=1<<9; 						//CC1P=1 Ϊ½ز
//			}		    
//		}			     	    					   
//	}
//	TIM3->SR=0;//жϱ־λ 	     
//}
