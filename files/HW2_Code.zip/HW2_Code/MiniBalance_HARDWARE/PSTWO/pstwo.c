/***********************************************

All rights reserved
***********************************************/

#include "./PSTWO/pstwo.h"
#define DELAY_TIME  delay_us(5); 
u16 Handkey;	// 
u8 Comd[2]={0x01,0x42};	//start
u8 Data[9]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}; //save data
u16 MASK[]={
    PSB_SELECT,
    PSB_L3,
    PSB_R3 ,
    PSB_START,
    PSB_PAD_UP,
    PSB_PAD_RIGHT,
    PSB_PAD_DOWN,
    PSB_PAD_LEFT,
    PSB_L2,
    PSB_R2,
    PSB_L1,
    PSB_R1,
    PSB_GREEN,
    PSB_RED,
    PSB_BLUE,
    PSB_PINK
	};	//button

//The PS2 gamepad controls related variables
//PS2
int PS2_LX,PS2_LY,PS2_RX,PS2_RY,PS2_KEY; 

/**************************************************************************
Function: PS2_Init
Input   : none
Output  : none
**************************************************************************/	 	
	
void PS2_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(PS2_DI_GPIO_CLK|PS2_DO_GPIO_CLK,ENABLE);     //DI,DO 
	RCC_APB2PeriphClockCmd(PS2_CS_GPIO_CLK|PS2_CLK_GPIO_CLK,ENABLE);    //CS,CLK
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;           				//
	GPIO_InitStructure.GPIO_Pin=PS2_DI_GPIO_PIN;                 		// DI 
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(PS2_DI_GPIO_PORT,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;              		//
	GPIO_InitStructure.GPIO_Pin=PS2_DO_GPIO_PIN;                 		// DO 
	GPIO_Init(PS2_DO_GPIO_PORT,&GPIO_InitStructure);
	
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;           			//
	GPIO_InitStructure.GPIO_Pin=PS2_CS_GPIO_PIN;     					// CS  
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(PS2_CS_GPIO_PORT,&GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;           			//
	GPIO_InitStructure.GPIO_Pin=PS2_CLK_GPIO_PIN;     					// CLK  
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(PS2_CLK_GPIO_PORT,&GPIO_InitStructure);

	
//	PWR->CR|=1<<8;	
//	RCC->BDCR&=0xFFFFFFFE;		
//	BKP->CR&=0xFFFFFFFE; 	
//	PWR->CR&=0xFFFFFEFF;	
}
/**************************************************************************
Function: Sent_Cmd
Input   : none
Output  : none
**************************************************************************/	 	
//
void PS2_Cmd(u8 CMD)
{
	volatile u16 ref=0x01;
	Data[1] = 0;
	for(ref=0x01;ref<0x0100;ref<<=1)
	{
		if(ref&CMD)
		{
			DO_H;                  	 //
		}
		else DO_L;

		CLK_H;                        //
		DELAY_TIME;
		CLK_L;
		DELAY_TIME;
		CLK_H;
		if(DI)
			Data[1] = ref|Data[1];
	}
	delay_us(16);
}

u8 PS2_RedLight(void)
{
	CS_L;
	PS2_Cmd(Comd[0]);  //
	PS2_Cmd(Comd[1]);  //
	CS_H;
	if( Data[1] == 0X73)   return 0 ;
	else return 1;

}
//
void PS2_ReadData(void)
{
	volatile u8 byte=0;
	volatile u16 ref=0x01;
	CS_L;
	PS2_Cmd(Comd[0]);  //
	PS2_Cmd(Comd[1]);  //
	for(byte=2;byte<9;byte++)          //
	{
		for(ref=0x01;ref<0x100;ref<<=1)
		{
			CLK_H;
			DELAY_TIME;
			CLK_L;
			DELAY_TIME;
			CLK_H;
		      if(DI)
		      Data[byte] = ref|Data[byte];
		}
        delay_us(16);
	}
	CS_H;
}


u8 PS2_DataKey()
{
	u8 index;

	PS2_ClearData();
	PS2_ReadData();

	Handkey=(Data[4]<<8)|Data[3];     
	for(index=0;index<16;index++)
	{	    
		if((Handkey&(1<<(MASK[index]-1)))==0)
		return index+1;
	}
	return 0;          //
}

//0~256
u8 PS2_AnologData(u8 button)
{
	return Data[button];
}

//clear data
void PS2_ClearData()
{
	u8 a;
	for(a=0;a<9;a++)
		Data[a]=0x00;
}
/******************************************************
Function:    void PS2_Vibration(u8 motor1, u8 motor2)
Description: 
Calls:		 void PS2_Cmd(u8 CMD);
Input: motor1:0x00 close
	   motor2:0x40~0xFF 
******************************************************/
void PS2_Vibration(u8 motor1, u8 motor2)
{
	CS_L;
	delay_us(16);
    PS2_Cmd(0x01);  //start 
	PS2_Cmd(0x42);  //call data
	PS2_Cmd(0X00);
	PS2_Cmd(motor1);
	PS2_Cmd(motor2);
	PS2_Cmd(0X00);
	PS2_Cmd(0X00);
	PS2_Cmd(0X00);
	PS2_Cmd(0X00);
	CS_H;
	delay_us(16);  
}
//short poll
void PS2_ShortPoll(void)
{
	CS_L;
	delay_us(16);
	PS2_Cmd(0x01);  
	PS2_Cmd(0x42);  
	PS2_Cmd(0X00);
	PS2_Cmd(0x00);
	PS2_Cmd(0x00);
	CS_H;
	delay_us(16);	
}
//
void PS2_EnterConfing(void)
{
    CS_L;
	delay_us(16);
	PS2_Cmd(0x01);  
	PS2_Cmd(0x43);  
	PS2_Cmd(0X00);
	PS2_Cmd(0x01);
	PS2_Cmd(0x00);
	PS2_Cmd(0X00);
	PS2_Cmd(0X00);
	PS2_Cmd(0X00);
	PS2_Cmd(0X00);
	CS_H;
	delay_us(16);
}
//
void PS2_TurnOnAnalogMode(void)
{
	CS_L;
	PS2_Cmd(0x01);  
	PS2_Cmd(0x44);  
	PS2_Cmd(0X00);
	PS2_Cmd(0x01); //analog=0x01;digital=0x00  
	PS2_Cmd(0x03); //Ox03
				   //
	PS2_Cmd(0X00);
	PS2_Cmd(0X00);
	PS2_Cmd(0X00);
	PS2_Cmd(0X00);
	CS_H;
	delay_us(16);
}
//
void PS2_VibrationMode(void)
{
	CS_L;
	delay_us(16);
	PS2_Cmd(0x01);  
	PS2_Cmd(0x4D);  
	PS2_Cmd(0X00);
	PS2_Cmd(0x00);
	PS2_Cmd(0X01);
	CS_H;
	delay_us(16);	
}
//
void PS2_ExitConfing(void)
{
    CS_L;
	delay_us(16);
	PS2_Cmd(0x01);  
	PS2_Cmd(0x43);  
	PS2_Cmd(0X00);
	PS2_Cmd(0x00);
	PS2_Cmd(0x5A);
	PS2_Cmd(0x5A);
	PS2_Cmd(0x5A);
	PS2_Cmd(0x5A);
	PS2_Cmd(0x5A);
	CS_H;
	delay_us(16);
}
//
void PS2_SetInit(void)
{
	PS2_ShortPoll();
	PS2_ShortPoll();
	PS2_ShortPoll();
	PS2_EnterConfing();		//
	PS2_TurnOnAnalogMode();	//
	//PS2_VibrationMode();	//
	PS2_ExitConfing();		//
}



/**************************************************************************
Function: Read the control of the ps2 handle
Input   : none
Output  : none
**************************************************************************/
void PS2_Read(void)
{
	static int Strat;
	//Reading key
	PS2_KEY=PS2_DataKey(); 
	//Read the analog of the remote sensing x axis on the left
	PS2_LX=PS2_AnologData(PSS_LX); 
	//Read the analog of the directional direction of remote sensing on the left
	PS2_LY=PS2_AnologData(PSS_LY);
	//Read the analog of the remote sensing x axis 
	PS2_RX=PS2_AnologData(PSS_RX);
	//Read the analog of the directional direction of the remote sensing y axis 
	PS2_RY=PS2_AnologData(PSS_RY);  

	if(PS2_KEY==4&&PS2_ON_Flag==0) 
		//The start button on the // handle is pressed
		Strat=1; 
	//When the button is pressed, you need to push the right side forward to the formal ps2 control car
	if(Strat&&(PS2_LY<118)&&PS2_ON_Flag==0)
	{
		PS2_ON_Flag=RC_ON;
		RC_Velocity = Default_Velocity;
	  RC_Turn_Velocity = Default_Turn_Bias;
	}
	
}

/**************************************************************************
Function: PS2_Control
Input   : none
Output  : none
**************************************************************************/	 	
void PS2_Control(void)
{
	int LY,RX;									
	int Threshold=20; 							
	static u8 Key1_Count = 0,Key2_Count = 0;	
	LY=-(PS2_LY-128);//
	RX=-(PS2_RX-128);//

	if(LY>-Threshold&&LY<Threshold)	LY=0;
	if(RX>-Threshold&&RX<Threshold)	RX=0;		//
	
	Move_X = (RC_Velocity/128)*LY;				//

	if(Move_X>=0)
		Move_Z = -(RC_Turn_Velocity/128)*RX;	//
	else
		Move_Z = (RC_Turn_Velocity/128)*RX;
	if (PS2_KEY == PSB_L1) 					 	//
	{	
		if((++Key1_Count) == 20)				//
		{
			PS2_KEY = 0;
			Key1_Count = 0;
			if((RC_Velocity += X_Step)>MAX_RC_Velocity)				//
				RC_Velocity = MAX_RC_Velocity;

				if((RC_Turn_Velocity += Z_Step)>MAX_RC_Turn_Bias)	//
					RC_Turn_Velocity = MAX_RC_Turn_Bias;
			}
	}
	else if(PS2_KEY == PSB_R1) 					//
	{
		if((++Key2_Count) == 20)
		{
			PS2_KEY = 0;
			Key2_Count = 0;
			if((RC_Velocity -= X_Step)<MINI_RC_Velocity)			//100mm/s
				RC_Velocity = MINI_RC_Velocity;
			
			if((RC_Turn_Velocity -= Z_Step)<MINI_RC_Turn_Velocity)//200
			   RC_Turn_Velocity = MINI_RC_Turn_Velocity;
		}
	}
	else
		Key2_Count = 0,Key2_Count = 0;			//
}


