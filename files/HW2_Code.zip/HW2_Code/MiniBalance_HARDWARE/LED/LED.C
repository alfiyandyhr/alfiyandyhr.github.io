/***********************************************

All rights reserved
***********************************************/
#include "led.h"
/**************************************************************************
Function: Led initialization
Input   : none
Output  : none
**************************************************************************/
void LED_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE); //
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;	            //˿
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;      //
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;     //50M
  GPIO_Init(GPIOC, &GPIO_InitStructure);	//
}

/**************************************************************************
Function: Led flashing
Input   : timeFlicker frequency
Output  : none
**************************************************************************/
void Led_Flash(u16 time)
{
	 static int temp;
	 if(0==time) LED=1;
	 else 	if(++temp==time)	LED=~LED,temp=0;
}
