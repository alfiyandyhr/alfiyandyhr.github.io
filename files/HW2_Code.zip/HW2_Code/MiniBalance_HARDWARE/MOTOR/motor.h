/***********************************************

All rights reserved
***********************************************/
#ifndef __MOTOR_H
#define __MOTOR_H
#include <sys.h>	 

//PWM          //PWMX_IN1 
                               //PWMX_IN1 
#define PWMA_IN1 TIM3->CCR1   
#define PWMA_IN2 TIM3->CCR2   
#define PWMB_IN1 TIM3->CCR3
#define PWMB_IN2 TIM3->CCR4



void MiniBalance_PWM_Init(u16 arr,u16 psc);
#endif
