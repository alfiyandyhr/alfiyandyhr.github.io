/***********************************************

All rights reserved
***********************************************/
#include "motor.h"
/**************************************************************************
Function: PWM_OutPut_TIM_GPIO_Config
Input   : none
Output  : none
**************************************************************************/	 	
static void PWM_OutPut_TIM_GPIO_Config(void) 
{
	GPIO_InitTypeDef GPIO_InitStructure;

	// Ƚͨ1 GPIO ʼ
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// Ƚͨ2 GPIO ʼ
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// Ƚͨ3 GPIO ʼ
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// Ƚͨ4 GPIO ʼ
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}


///*
// * ע⣺TIM_TimeBaseInitTypeDefṹ5ԱTIM6TIM7ļĴֻ
// * TIM_PrescalerTIM_PeriodʹTIM6TIM7ʱֻʼԱɣ
// * Աͨöʱ͸߼ʱ.
// *-----------------------------------------------------------------------------
// *typedef struct
// *{ TIM_Prescaler            
// *	TIM_CounterMode			     TIMx,x[6,7]ûУ
// *  TIM_Period               
// *  TIM_ClockDivision        TIMx,x[6,7]ûУ
// *  TIM_RepetitionCounter    TIMx,x[1,8,15,16,17]
// *}TIM_TimeBaseInitTypeDef; 
// *-----------------------------------------------------------------------------
// */

/* ----------------   PWMź ںռձȵļ--------------- */
// ARR ԶװؼĴֵ
// CLK_cntʱӣ Fck_int / (psc+1) = 72M/(psc+1)
// PWM źŵ T = ARR * (1/CLK_cnt) = ARR*(PSC+1) / 72M
// ռձP=CCR/(ARR+1)

/**************************************************************************
Function: PWM_OutPut_TIM_Mode_Config
Input   : none
Output  : none
**************************************************************************/	 	
static void PWM_OutPut_TIM_Mode_Config(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_OCInitTypeDef TIM_OCInitStruct;

  // ʱʱ,ڲʱCK_INT=72M
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);

	/*--------------------ʱṹʼ-------------------------*/

	TIM_TimeBaseInitStruct.TIM_Period = arr;              			
	TIM_TimeBaseInitStruct.TIM_Prescaler  = psc;          			
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;	
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;        //
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct);      	//

	
	/*--------------------------------------*/	
	TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;             		//
	TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable; 		//
	TIM_OCInitStruct.TIM_Pulse = 0;                            		//
	TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;     		//
	TIM_OC1Init(TIM3,&TIM_OCInitStruct);                	//

	TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;             		//
	TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable; 		//
	TIM_OCInitStruct.TIM_Pulse = 0;                            		//
	TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;     		//
	TIM_OC2Init(TIM3,&TIM_OCInitStruct);                 	//ʼȽϲ

	TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;             		//
	TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable; 		//
	TIM_OCInitStruct.TIM_Pulse = 0;                            		//
	TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;     		//
	TIM_OC3Init(TIM3,&TIM_OCInitStruct);                  //ʼȽϲ

	TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;             		//
	TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable; 		//
	TIM_OCInitStruct.TIM_Pulse = 0;                            		//
	TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;     		//
	TIM_OC4Init(TIM3,&TIM_OCInitStruct);                  //ʼȽϲ

	TIM_OC1PreloadConfig(TIM3,TIM_OCPreload_Enable);   	//CH1
	TIM_OC2PreloadConfig(TIM3,TIM_OCPreload_Enable);   	//CH2
	TIM_OC3PreloadConfig(TIM3,TIM_OCPreload_Enable);   	//CH3
	TIM_OC4PreloadConfig(TIM3,TIM_OCPreload_Enable);   	//CH4

	TIM_ARRPreloadConfig(TIM3, ENABLE);                	//

	TIM_Cmd(TIM3,ENABLE);                              	//
}

void MiniBalance_PWM_Init(u16 arr,u16 psc)
{
	PWM_OutPut_TIM_GPIO_Config();			//GPIO
	PWM_OutPut_TIM_Mode_Config(arr,psc);	//
}
