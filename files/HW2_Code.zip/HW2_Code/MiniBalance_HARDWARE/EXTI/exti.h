/***********************************************


All rights reserved
***********************************************/
#ifndef __EXTI_H
#define __EXIT_H	 
#include "sys.h"
#define INT PBin(9)   //PB9ӵMPU6050ж
void MiniBalance_EXTI_Init(void);	//ⲿжϳʼ		 					    
#endif

























