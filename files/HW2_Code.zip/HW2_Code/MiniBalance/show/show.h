/***********************************************

All rights reserved
***********************************************/
#ifndef __SHOW_H
#define __SHOW_H
#include "sys.h"
extern float Velocity_Left,Velocity_Right;//
extern float Displacement;                //
void oled_show(void);
void APP_Show(void);
void DataScope(void);
void OLED_Show_CCD(void);
void OLED_DrawPoint_Shu(u8 x,u8 y,u8 t);
#endif
