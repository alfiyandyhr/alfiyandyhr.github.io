///***********************************************
//All rights reserved
//***********************************************/


//#include "ELE_CCD.h"

//int Sensor_Left,Sensor_Middle,Sensor_Right,Sensor;
//u16  CCD_ADV[128]={0};
//u8 CCD_Median,CCD_Threshold;                 


///**************************************************************************
//Function: ELE_ADC_GPIO_Config
//Input   : none
//Output  : none
//**************************************************************************/	 	
//static void ELE_ADC_GPIO_Config(void)
//{
//	GPIO_InitTypeDef GPIO_InitStructure;
//	
//	// ADC IO
//	RCC_APB2PeriphClockCmd ( ELE_ADC_L_GPIO_CLK|ELE_ADC_M_GPIO_CLK|ELE_ADC_R_GPIO_CLK, ENABLE );
//	
//	GPIO_InitStructure.GPIO_Pin = ELE_ADC_L_PIN;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//	GPIO_Init(ELE_ADC_L_PORT, &GPIO_InitStructure);	

//	//
//	GPIO_InitStructure.GPIO_Pin = ELE_ADC_M_PIN;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//	GPIO_Init(ELE_ADC_M_PORT, &GPIO_InitStructure);				


//	GPIO_InitStructure.GPIO_Pin = ELE_ADC_R_PIN;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//	GPIO_Init(ELE_ADC_R_PORT, &GPIO_InitStructure);				
//	
//}

///**************************************************************************
//Function: ELE_ADC_Mode_Config
//Input   : none
//Output  : none
//**************************************************************************/	 	

//static void ELE_ADC_Mode_Config(void)
//{
//	ADC_InitTypeDef ADC_InitStructure;	

//	// ADCʱ
//	ELE_ADC_APBxClock_FUN ( ELE_ADC_CLK, ENABLE );
//	
//	//λADC1, ADC1 ȫĴΪȱʡֵ
//	ADC_DeInit(ELE_ADC); 

//	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
//	
//	ADC_InitStructure.ADC_ScanConvMode = DISABLE ; 

//	// ת
//	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;


//	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;

//	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
//	
//	ADC_InitStructure.ADC_NbrOfChannel = 1;	
//		
//	// ʼADC
//	ADC_Init(ELE_ADC, &ADC_InitStructure);
//	
//	// ADCʱΪPCLK26Ƶ12MHz
//	RCC_ADCCLKConfig(RCC_PCLK2_Div8); 
//	
//	ADC_RegularChannelConfig(ELE_ADC, ELE_ADC_L_CHANNEL, 1, 
//	                         ADC_SampleTime_239Cycles5);
//							 
//	ADC_RegularChannelConfig(ELE_ADC, ELE_ADC_M_CHANNEL, 1, 
//	                         ADC_SampleTime_239Cycles5);

//	ADC_RegularChannelConfig(ELE_ADC, ELE_ADC_R_CHANNEL, 1, 
//	                         ADC_SampleTime_239Cycles5);
//		
//	// ж
//	ADC_ITConfig(ELE_ADC, ADC_IT_EOC, DISABLE);
//	
//	ADC_Cmd(ELE_ADC, ENABLE);
//	
//	ADC_ResetCalibration(ELE_ADC);
//	while(ADC_GetResetCalibrationStatus(ELE_ADC));
//	
//	ADC_StartCalibration(ELE_ADC);
//	while(ADC_GetCalibrationStatus(ELE_ADC));
//	
//}

///**************************************************************************
//Function: ELE_ADC_Init
//Input   : none
//Output  : none
//**************************************************************************/	 	
//void ELE_ADC_Init(void)
//{
//	ELE_ADC_GPIO_Config();
//	ELE_ADC_Mode_Config();

//}


///**************************************************************************
//Function: CCD_ADC_Mode_Config
//Input   : none
//Output  : none
//**************************************************************************/	 	
//static void CCD_ADC_Mode_Config(void)
//{
//	ADC_InitTypeDef ADC_InitStructure;	

//	CCD_ADC_APBxClock_FUN ( CCD_ADC_CLK, ENABLE );
//	
//	//λADC1, ADC1 ȫĴΪȱʡֵ
//	ADC_DeInit(CCD_ADC); 


//	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
//	

//	ADC_InitStructure.ADC_ScanConvMode = DISABLE ; 

//	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;

//	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;


//	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
//	
//	ADC_InitStructure.ADC_NbrOfChannel = 1;	
//		
//	// ʼADC
//	ADC_Init(CCD_ADC, &ADC_InitStructure);
//	
//	// ADCʱΪPCLK26Ƶ12MHz
//	RCC_ADCCLKConfig(RCC_PCLK2_Div6); 

//	ADC_RegularChannelConfig(CCD_ADC, CCD_ADC_CHANNEL, 1, 
//	                         ADC_SampleTime_239Cycles5);
//		
//	// ж
//	ADC_ITConfig(CCD_ADC, ADC_IT_EOC, DISABLE);
//	
//	// ADC ʼת
//	ADC_Cmd(CCD_ADC, ENABLE);
//	

//	ADC_ResetCalibration(CCD_ADC);
//	while(ADC_GetResetCalibrationStatus(CCD_ADC));
//	
//	ADC_StartCalibration(CCD_ADC);

//	while(ADC_GetCalibrationStatus(CCD_ADC));
//}


///**************************************************************************
//Function: CCD_GPIO_Config
//Input   : none
//Output  : none
//**************************************************************************/	 	
//static void CCD_GPIO_Config(void)
//{
//	GPIO_InitTypeDef GPIO_InitStructure;
//	
//	RCC_APB2PeriphClockCmd ( TSL_CLK_GPIO_CLK|TSL_SI_GPIO_CLK|CCD_ADC_GPIO_CLK, ENABLE );
//	
//	GPIO_InitStructure.GPIO_Pin = TSL_SI_PIN;				//PA4
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//	GPIO_Init(TSL_SI_PORT, &GPIO_InitStructure);	


//	GPIO_InitStructure.GPIO_Pin = TSL_CLK_PIN;				//PA5
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//	GPIO_Init(TSL_CLK_PORT, &GPIO_InitStructure);				


//	//ADCģʽ
//	GPIO_InitStructure.GPIO_Pin = CCD_ADC_PIN;				//PC5
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//	GPIO_Init(CCD_ADC_PORT, &GPIO_InitStructure);				
//	
//}


///**************************************************************************
//Function: CCD_Init
//Input   : none
//Output  : none
//ܣʼCCDѲ
//ڲ: 
//  ֵ
//**************************************************************************/	 	
//void CCD_Init(void)
//{
//	CCD_GPIO_Config();
//	CCD_ADC_Mode_Config();

//}

///**************************************************************************
//Function: ELE_Mode
//Input   : none
//Output  : none
//**************************************************************************/	 	
//void ELE_Mode(void)
//{
//	if(Mode == ELE_Line_Patrol_Mode && Flag_Left!=1 &&Flag_Right!=1)
//	{
//		int Sum = 0;
//		Sensor_Left = Get_Adc(ELE_ADC_L_CHANNEL);
//		Sensor_Middle = Get_Adc(ELE_ADC_M_CHANNEL);
//		Sensor_Right = Get_Adc(ELE_ADC_R_CHANNEL);
//		Sum = Sensor_Left*1+Sensor_Middle*100+Sensor_Right*199;			
//		Sensor = Sum/(Sensor_Left+Sensor_Middle+Sensor_Right);
//		if(Detect_Barrier() == No_Barrier)		//⵽ϰ
//				Target_x_speed=tracking_speed;       //Сһ300mm/sٶ
//		else									//ϰ
//		{
//			if(!Flag_Stop)
//				Buzzer_Alarm(100);				//ʹܵʱϰ
//			else 
//				Buzzer_Alarm(0);
//			Target_x_speed = 0;
//		}	
//	}
//	Target_gyro_z=ELE_turn(Encoder_Left,Encoder_Right,Gyro_Turn);
//	
//}

//**************************************************************************/
//int ELE_turn(int encoder_left,int encoder_right,float gyro)//ת
//{
//	float Turn;     
//	float Bias,kp=60,Kd=0.2;	  
//	Bias=Sensor-100;
//	Turn=-Bias*kp/100-gyro*Kd/100;
//	if(Detect_Barrier() == Barrier_Detected)		
//	{
//		if(!Flag_Stop)
//			Turn = 0;
//		}	
//	  return Turn;
//}

///**************************************************************************
//Function: Detect_Barrier
//Input   : none
//Output  : 1or0(Barrier_Detected or No_Barrier)
//**************************************************************************/	 	
////ϰ
//u8 Detect_Barrier(void)
//{
//	u8 i;
//	u8 point_count = 0;
//	if(Lidar_Detect == Lidar_Detect_ON)
//	{
//		for(i=0;i<225;i++)	//Ƿϰ
//		{
//			if(Dataprocess[i].angle>340 || Dataprocess[i].angle <20) //Сǰ40㷶Χ
//			{
//				if(0<Dataprocess[i].distance&&Dataprocess[i].distance<Detect_distance)//700mmǷϰ
//				  point_count++,Distance=Dataprocess[i].distance;
//			}
//		}
//		if(point_count > 3)//ϰ
//			return Barrier_Detected;
//		else
//			return No_Barrier;
//	}
//	else
//		return No_Barrier;
//}
///**************************************************************************
//**************************************************************************/
//void Dly_us(void)
//{
//   int ii;    
//   for(ii=0;ii<10;ii++);      
//}

///**************************************************************************
//Function: Read_TSL
//Input   : none
//Output  : none
//**************************************************************************/	 	
////ȡCCDģ
//void RD_TSL(void) 
//{
//	u8 i=0,tslp=0;
//	
//	TSL_CLK_HIGH;
//	TSL_SI_LOW;
//	Dly_us();
//	Dly_us();

//	TSL_CLK_LOW;
//	TSL_SI_LOW;
//	Dly_us();
//	Dly_us();

//	TSL_CLK_LOW;
//	TSL_SI_HIGH;
//	Dly_us();
//	Dly_us();

//	TSL_CLK_HIGH;
//	TSL_SI_HIGH;
//	Dly_us();
//	Dly_us();

//	TSL_CLK_HIGH;
//	TSL_SI_LOW;
//	Dly_us();
//	Dly_us();
//	
//	for(i=0;i<128;i++)
//	{ 
//		TSL_CLK_LOW; 
//		Dly_us();  //عʱ
//		Dly_us();
//		CCD_ADV[tslp]=(Get_Adc(CCD_ADC_CHANNEL))>>4;		
//		++tslp;
//		TSL_CLK_HIGH;
//		Dly_us();  
//	}
//}


///**************************************************************************
//ܣCCDȡֵ
//ڲ
//  ֵ
//**************************************************************************/
//void  Find_CCD_Median(void)
//{ 
//	static u8 i,j,Left,Right,Last_CCD_Zhongzhi;
//	static u16 value1_max,value1_min;

//	value1_max=CCD_ADV[0];  //ֵ̬㷨ȡСֵ
//	for(i=15;i<123;i++)   //߸ȥ15
//	{
//		if(value1_max<=CCD_ADV[i])
//		value1_max=CCD_ADV[i];
//	}
//	value1_min=CCD_ADV[0];  //Сֵ
//	for(i=15;i<123;i++) 
//	{
//		if(value1_min>=CCD_ADV[i])
//		value1_min=CCD_ADV[i];
//	}
//	CCD_Yuzhi=(value1_max+value1_min)/2;	  //ȡֵ
//	for(i = 15;i<118; i++)   //Ѱ
//	{
//		if(CCD_ADV[i]>CCD_Yuzhi&&CCD_ADV[i+1]>CCD_Yuzhi&&CCD_ADV[i+2]>CCD_Yuzhi&&CCD_ADV[i+3]<CCD_Yuzhi&&CCD_ADV[i+4]<CCD_Yuzhi&&CCD_ADV[i+5]<CCD_Yuzhi)
//		{	
//			Left=i;
//			break;	
//		}
//	}
//	for(j = 118;j>15; j--)//Ѱұ
//	{
//		if(CCD_ADV[j]<CCD_Yuzhi&&CCD_ADV[j+1]<CCD_Yuzhi&&CCD_ADV[j+2]<CCD_Yuzhi&&CCD_ADV[j+3]>CCD_Yuzhi&&CCD_ADV[j+4]>CCD_Yuzhi&&CCD_ADV[j+5]>CCD_Yuzhi)
//		{	
//			Right=j;
//			break;	
//		}
//	}
//	CCD_Zhongzhi=(Right+Left)/2;//λ
//	if(myabs(CCD_Zhongzhi-Last_CCD_Zhongzhi)>90)   //ߵƫ̫
//		CCD_Zhongzhi=Last_CCD_Zhongzhi;    //ȡһεֵ
//	Last_CCD_Zhongzhi=CCD_Zhongzhi;  //һεƫ
//}	
///**************************************************************************
//Function: CCD_Mode
//Input   : none
//Output  : none
//ܣCCDѲģʽ
//ڲ: 
//  ֵ
//**************************************************************************/	 	
//void CCD_Mode(void)
//{
//	static u8 Count_CCD = 0;								//CCDƵ
//	if(Mode == CCD_Line_Patrol_Mode && Flag_Left !=1 &&Flag_Right !=1)
//	{
//		if(++Count_CCD == 4)									//ڿƵʣ4*5 = 20msһ
//		{
//			RD_TSL(); 
//      Find_CCD_Median();	//ֵ					
//      Count_CCD = 0;			
//		}
//		else if(Count_CCD>4)  Count_CCD = 0;
//	 if(Detect_Barrier() == No_Barrier)		  //⵽ϰ
//	    Target_x_speed = tracking_speed;		//CCDѲٶ
//		Target_gyro_z=CCD_turn(CCD_Zhongzhi,Gyro_Turn);
//	}
//}	


///**************************************************************************
//ܣCCDģʽת  Ѳ
//ڲCCDȡ Z
//  ֵתPWM
//    ߣƽС֮
//**************************************************************************/
//int CCD_turn(u8 CCD,float gyro)//ת
//{
//	  float Turn;     
//    float Bias,kp=30,Kd=0.12;	  
//	  Bias=CCD-64;
//	  Turn=Bias*kp/100+gyro*Kd/100;
//	  return Turn;
//}

